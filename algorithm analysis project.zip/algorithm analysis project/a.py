import heapq

class AStar:
    V = 24

    class Node:
        def _init_(self, vertex, distance, bandwidth, delay, reliability):
            self.vertex = vertex
            self.distance = distance
            self.bandwidth = bandwidth
            self.delay = delay
            self.reliability = reliability

        def _lt_(self, other):
            return (self.distance + self.calculateHeuristic()) < (other.distance + other.calculateHeuristic())

        def calculateHeuristic(self):
            return 0

    def printSolution(self, dist, bandwidth, delay, reliability):
        print("Vertex Distance Bandwidth Delay Reliability")
        for i in range(self.V):
            print(f"{i} \t {dist[i]} \t\t {bandwidth[i]} \t\t {delay[i]} \t\t {reliability[i]:.2f} \t\t")

    def aStar(self, graph, bandwidth, delay, reliability, src):
        dist = [float('inf')] * self.V
        bw = [0] * self.V
        delayArr = [0] * self.V
        reliabilityArr = [0.0] * self.V
        delayThreshold = 40
        reliabilityThreshold = 0.70
        priorityQueue = []
        visited = set()

        for i in range(self.V):
            dist[i] = float('inf')
            bw[i] = 0
            delayArr[i] = 0
            reliabilityArr[i] = 0.0

        dist[src] = 0
        bw[src] = 5
        heapq.heappush(priorityQueue, self.Node(src, 0, 0, 0, 0.0))

        while priorityQueue:
            currentNode = heapq.heappop(priorityQueue)
            u = currentNode.vertex

            if u in visited:
                continue

            visited.add(u)

            for v in range(self.V):
                if graph[u][v] != 0 and v not in visited and delayArr[u] + delay[u][v] < delayThreshold and reliability[u][v] >= reliabilityThreshold:

                    newDistance = currentNode.distance + graph[u][v]
                    newBandwidth = currentNode.bandwidth + bandwidth[u][v]
                    newDelay = currentNode.delay + delay[u][v]
                    newReliability = currentNode.reliability + reliability[u][v]

                    if newDistance < dist[v]:
                        dist[v] = newDistance
                        bw[v] = newBandwidth
                        delayArr[v] = newDelay
                        reliabilityArr[v] = newReliability
                        heapq.heappush(priorityQueue, self.Node(v, newDistance, newBandwidth, newDelay, newReliability))

        self.printSolution(dist, bw, delayArr, reliabilityArr)

if _name_ == "_main_":
    graph = [
        [0, 3, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0],
        [3, 0, 3, 0, 0, 5, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0],
        [0, 3, 0, 5, 2, 0, 5, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0],
        [0, 0, 5, 0, 5, 0, 4, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0],
        [0, 0, 2, 5, 0, 0, 0, 4, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0],
        [1, 5, 0, 0, 0, 0, 3, 0, 3, 0, 2, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0]
    ]

    bandwidth = [
        [0, 5, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0],
        [5, 0, 5, 0, 0, 2, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0],
        [0, 5, 0, 2, 1, 0, 4, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0],
        [0, 0, 2, 0, 3, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0],
        [0, 0, 1, 3, 0, 0, 0, 2, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0],
        [1, 2, 0, 0, 0, 0, 3, 0, 4, 0, 2, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0]
    ]

    delay = [
        [0, 10, 0, 0, 0, 5, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0],
        [10, 0, 15, 0, 0, 8, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0],
        [0, 15, 0, 8, 5, 0, 12, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0],
        [0, 0, 8, 0, 10, 0, 6, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0],
        [0, 0, 5, 10, 0, 0, 0, 8, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0],
        [5, 8, 0, 0, 0, 0, 4, 0, 6, 0, 3, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0]
    ]

    reliability = [
        [0.0, 0.9, 0.0, 0.0, 0.0, 0.8, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0],
        [0.9, 0.0, 0.7, 0.0, 0.0, 0.6, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0],
        [0.0, 0.7, 0.0, 0.6, 0.8, 0.0, 0.5, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0],
        [0.0, 0.0, 0.6, 0.0, 0.9, 0.0, 0.7, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0],
        [0.0, 0.0, 0.8, 0.9, 0.0, 0.0, 0.0, 0.6, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0],
        [0.8, 0.6, 0.0, 0.0, 0.0, 0.0, 0.4, 0.0, 0.3, 0.0, 0.2, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0]
    ]

    astar = AStar()
    astar.aStar(graph, bandwidth, delay, reliability, 0)